#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void update_column(char *text);
unsigned hash_pjw(char *name);

#endif