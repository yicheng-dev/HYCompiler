int main()
{
    int i, j;

    f(1, 1);
    // a[5,3] = 1.5;
    if (a == 0){
        i = 1 1;
    }
    else{
        i = ;
    }
}